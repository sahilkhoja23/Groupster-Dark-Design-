iOS 7 Wireframe Kit
===================

###An Illustrator kit to make your wireframing a day at the beach

http://blakeperdue.com/ios7-wireframe-kit

Born out of a need for a good way to rapidly wireframe in Illustrator, this kit contains the most common UI elements in iOS 7 Beta 3. If you spot something I missed, fork it or shoot me a note.

![iOS 7 Wireframe Kit Preview](iOS7-Wireframe-Kit.png "iOS 7 Wireframe Kit Preview")
![iOS 7 Wireframe Kit Preview (Omnigraffle)](https://github.com/SidneyS/ios7-wireframe-kit/raw/master/iOS7-Wireframe-Kit-Example-Omnigraffle.png "iOS 7 Wireframe Kit Preview (Omnigraffle)")

[Creative Commons Attribution-NoDerivs 3.0 Unported License](https://creativecommons.org/licenses/by-nd/3.0/)
